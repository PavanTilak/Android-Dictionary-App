package com.example.dictionaryapp.model

import java.util.ArrayList

class ListModel(
        /**
         * {1 item
         * "list":[10 items
         * 0:{...}11 items
         * 1:{...}11 items
         * 2:{...}11 items
         * 3:{...}11 items
         * 4:{...}11 items
         * 5:{...}11 items
         * 6:{...}11 items
         * 7:{...}11 items
         * 8:{...}11 items
         * 9:{...}11 items
         * ]
         * }
         */
        var list: ArrayList<DictionaryModel>)
