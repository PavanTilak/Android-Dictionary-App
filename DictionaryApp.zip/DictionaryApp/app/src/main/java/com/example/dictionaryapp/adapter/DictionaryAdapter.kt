package com.example.dictionaryapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.dictionaryapp.R
import com.example.dictionaryapp.model.DictionaryModel
import java.util.ArrayList

class DictionaryAdapter(private val mDictionaryList: ArrayList<DictionaryModel>?, private val context: Context) : RecyclerView.Adapter<DictionaryAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.dictionary_row, parent, false)

        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val dictionaryModel = mDictionaryList!![position]

        holder.definition.text = "Definition : " + dictionaryModel.definition
        holder.thumsUp.text = "ThumbsUp : " + dictionaryModel.thumbs_up
        holder.thumsDown.text = "ThumbsDown : " + dictionaryModel.thumbs_down
    }


    override fun getItemCount(): Int {
        return mDictionaryList?.size ?: 0
    }

    class ViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        val definition: TextView
        val thumsUp: TextView
        val thumsDown: TextView

        init {
            definition = view.findViewById(R.id.definition)
            thumsUp = view.findViewById(R.id.thumsUp)
            thumsDown = view.findViewById(R.id.thumsDown)
        }
    }

}
