package com.example.dictionaryapp.interfaces

import com.example.dictionaryapp.model.ListModel
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

/**
 * var req = unirest("GET", "https://mashape-community-urban-dictionary.p.rapidapi.com/define");
 *
 * req.query({
 * "term": "tilak"
 * });
 *
 * req.headers({
 * "x-rapidapi-host": "mashape-community-urban-dictionary.p.rapidapi.com",
 * "x-rapidapi-key": "5e1ba624a8mshc60d7108e2621fdp15cc6bjsn415bf172e99c",
 * "useQueryString": true
 * });
 */
interface IAwsDictionary {

    @GET("define")
    fun getDictionaryData(@Header("x-rapidapi-host") apiHost: String,
                          @Header("x-rapidapi-key") apiKey: String,
                          @Header("useQueryString") userQuery: Boolean,
                          @Query("term") searchTerm: String): Call<ListModel>
}
