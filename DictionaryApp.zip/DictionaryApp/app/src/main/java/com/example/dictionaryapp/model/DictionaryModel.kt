package com.example.dictionaryapp.model

class DictionaryModel(
        /**
         * {
         * {1 item
         * "list":[10 items
         * 0:{"definition":"A really great dude who will make your life [123]% better than it was. Can count on him to make you laugh at any moment, give really good life advice, and be down to blackout at any given moment. People will envy how much [fun you] have together but who cares. [Life of the party]."
         * "permalink":"http://pavan.urbanup.com/11631041"
         * "thumbs_up":125
         * "sound_urls":[]0 items
         * "author":"riri2525"
         * "word":"Pavan"
         * "defid":11631041
         * "current_vote":""
         * "written_on":"2017-05-30T00:00:00.000Z"
         * "example":"[You know] Pavan?? You're so [lucky]!!"
         * "thumbs_down":18
         * }]
         * }
         * }
         */
        var definition: String, var thumbs_up: Int, var thumbs_down: Int)
