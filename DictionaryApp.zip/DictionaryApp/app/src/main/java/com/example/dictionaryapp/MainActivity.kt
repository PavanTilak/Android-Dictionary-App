package com.example.dictionaryapp

import android.app.Activity
import android.app.ProgressDialog
import android.graphics.PorterDuff
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.example.dictionaryapp.adapter.DictionaryAdapter
import com.example.dictionaryapp.model.DictionaryModel
import com.example.dictionaryapp.model.ListModel
import com.example.dictionaryapp.utilities.Utils
import com.example.dictionaryapp.interfaces.IAwsDictionary
import com.example.dictionaryapp.utilities.Utils.checkNetworkState

import java.util.ArrayList
import java.util.Collections
import java.util.Comparator

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity(), Callback<ListModel> {

    private var mSearchInputbox: EditText? = null
    private var mSearchBtn: Button? = null
    private var mSortBtn: Button? = null
    private var mRecyclerView: RecyclerView? = null
    private var mLayoutManager: RecyclerView.LayoutManager? = null
    private var mRecyclerAdapter: RecyclerView.Adapter<*>? = null
    private var mEmptyView: TextView? = null
    private var mPopup: PopupMenu? = null
    private var mRestaurantsList: ArrayList<DictionaryModel>? = null
    private val TAG = "MainActivity"
    private var mProgressBar: ProgressBar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initViewIds()
    }

    private fun initViewIds() {
        mRecyclerView = findViewById(R.id.recycler_view)
        mEmptyView = findViewById(R.id.emptyStringView)
        mSearchBtn = findViewById(R.id.searchBtn)
        mProgressBar = findViewById(R.id.progressBar)
        mSearchBtn!!.setOnTouchListener { v, event ->

            if(checkNetworkState(this)) {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        v.background = getDrawable(R.drawable.ic_search_dim)
                    }
                    MotionEvent.ACTION_UP -> {
                        v.background = getDrawable(R.drawable.ic_search)
                        if (mSearchInputbox!!.text.toString().trim { it <= ' ' }.length > 0) {
                            mProgressBar!!.visibility = View.VISIBLE
                            hideSoftKeyboard()
                            backendApiCall()
                        } else {
                            Toast.makeText(this@MainActivity, resources.getText(R.string.empty_msg), Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                Toast.makeText(this@MainActivity, resources.getText(R.string.network_error), Toast.LENGTH_LONG).show()
            }
            true
        }

        mSearchInputbox = findViewById(R.id.searchText)
        mSearchInputbox!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
                mRecyclerView!!.visibility = View.GONE
                mEmptyView!!.visibility = View.VISIBLE
            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
            }
        })

        mSortBtn = findViewById(R.id.sortBtn)
        //Creating the instance of PopupMenu
        mPopup = PopupMenu(this@MainActivity, mSortBtn)
        //Inflating the Popup using xml file
        mPopup!!.menuInflater.inflate(R.menu.menu, mPopup!!.menu)
        mSortBtn!!.setOnClickListener {
            //registering popup with OnMenuItemClickListener
            mPopup!!.setOnMenuItemClickListener { item ->
                if (mRestaurantsList != null && mRestaurantsList!!.size > 0) {

                    if (item.title == resources.getString(R.string.thums_up)) {
                        Collections.sort(mRestaurantsList!!, SortByThumsUp())
                        mRecyclerAdapter!!.notifyDataSetChanged()
                    } else {
                        Collections.sort(mRestaurantsList!!, SortByThumsDown())
                        mRecyclerAdapter!!.notifyDataSetChanged()
                    }

                    Toast.makeText(this@MainActivity, "Sorting Dictionary by : " + item.title, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, resources.getText(R.string.empty_msg), Toast.LENGTH_SHORT).show()
                }
                true
            }

            mPopup!!.show()//showing popup menu
        }
    }

    private fun backendApiCall() {
        val retrofit = Retrofit.Builder()
                .baseUrl(Utils.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

        val dictionaryApi = retrofit.create(IAwsDictionary::class.java)

        val call = dictionaryApi.getDictionaryData(Utils.API_HOST,
                Utils.API_KEY, true, mSearchInputbox!!.text.toString().trim { it <= ' ' })
        call.enqueue(this)
    }

    override fun onResponse(call: Call<ListModel>, response: Response<ListModel>) {
        if (response.isSuccessful) {
            mProgressBar!!.visibility = View.GONE
            val listModel = response.body()
            if (listModel != null) {

                mRestaurantsList = listModel.list

                if (mRestaurantsList != null && mRestaurantsList!!.size > 0) {
                    mRecyclerAdapter = DictionaryAdapter(mRestaurantsList, this)
                    mLayoutManager = LinearLayoutManager(this)

                    mRecyclerView!!.layoutManager = mLayoutManager
                    mRecyclerView!!.visibility = View.VISIBLE
                    mEmptyView!!.visibility = View.GONE
                    mRecyclerView!!.adapter = mRecyclerAdapter
                }
            }
        } else {
            Log.d(TAG, "error response " + response.errorBody()!!)
        }
    }

    override fun onFailure(call: Call<ListModel>, t: Throwable) {
        mProgressBar!!.visibility = View.GONE
        Log.d(TAG, "Failure in response ")
        t.printStackTrace()
    }

    private fun hideSoftKeyboard() {
        val imm = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
    }

    inner class SortByThumsUp : Comparator<DictionaryModel> {
        override fun compare(p1: DictionaryModel, p2: DictionaryModel): Int {
            val pM1 = p1.thumbs_up
            val pM2 = p2.thumbs_up
            return if (pM1 < pM2) {
                1
            } else if (pM1 > pM2) {
                -1
            } else {
                0
            }
        }
    }

    inner class SortByThumsDown : Comparator<DictionaryModel> {
        override fun compare(p1: DictionaryModel, p2: DictionaryModel): Int {
            val pM1 = p1.thumbs_down
            val pM2 = p2.thumbs_down
            return if (pM1 < pM2) {
                1
            } else if (pM1 > pM2) {
                -1
            } else {
                0
            }
        }
    }

}