package com.example.dictionaryapp


import com.example.dictionaryapp.model.DictionaryModel
import com.example.dictionaryapp.model.ListModel

import junit.framework.Assert.assertEquals

object AssertHelper {
    fun assertListEquals(listModel1: ListModel, listModel2: ListModel) {
        assertEquals(listModel1.list[0].definition, listModel2.list[0].definition)
        assertEquals(listModel1.list[0].thumbs_up, listModel2.list[0].thumbs_up)
        assertEquals(listModel1.list[0].thumbs_down, listModel2.list[0].thumbs_down)
    }

    fun assertDictionaryEquals(dictionaryModel1: DictionaryModel, dictionaryModel2: DictionaryModel) {
        assertEquals(dictionaryModel1.definition, dictionaryModel2.definition)
        assertEquals(dictionaryModel1.thumbs_up, dictionaryModel2.thumbs_up)
        assertEquals(dictionaryModel1.thumbs_down, dictionaryModel2.thumbs_down)
    }
}
