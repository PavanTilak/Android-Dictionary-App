package com.example.dictionaryapp

import android.content.Intent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText

import androidx.recyclerview.widget.RecyclerView
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import androidx.test.rule.ActivityTestRule

import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.typeText
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.withText
import org.hamcrest.Matchers.greaterThan
import org.hamcrest.Matchers.instanceOf
import org.hamcrest.Matchers.notNullValue
import org.junit.Assert.assertThat

@MediumTest
@RunWith(AndroidJUnit4::class)
class MainActivityTest {

    @Rule
    var mActivityTestRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun launchActivity() {
        val intent = Intent()
        mActivityTestRule.launchActivity(intent)
    }

    @Test
    fun initialiseInput() {
        val activity = mActivityTestRule.activity
        val viewById = activity.findViewById<View>(R.id.searchText)
        assertThat(viewById, notNullValue())
        assertThat(viewById, instanceOf<Any>(EditText::class.java))
    }

    @Test
    fun inputText() {
        onView(withId(R.id.searchText))
                .perform(typeText("Pavan"))
    }

    @Test
    fun performClick() {
        onView(withId(R.id.searchBtn))
                .perform(click())
    }
}